#pragma once

#include "../screen/ssd1306.h"

#define BALL_RADIUS  9
#define BALL_DAMPING 0.95
#define BALL_ACCEL_SENSITIVITY 4.0
#define BALL_ENERGY_LOSS 0.7
#define BALL_BOUNDARY_MARGIN 1
#define BALL_DT 0.05
#define BALL_FPS  120
#define BALL_CALIB_SAMPLES 10

typedef struct ball_data {
    double x, y;
    double vx, vy;
} ball_data_t;

void accel_ball_demo(ssd1306_t* screen);