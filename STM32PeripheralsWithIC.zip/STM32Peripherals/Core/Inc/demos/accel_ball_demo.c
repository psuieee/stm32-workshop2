#include "accel_ball_demo.h"

#include <math.h>
#include <stdint.h>
#include <stdbool.h>

#include "../screen/ssd1306.h"
#include "../accel/mpu6050.h"
#include "../screen/font_16x16.h"

static const uint8_t SMILEY_BITMAP[16] = {
    0x00, 0x08, 0x12, 0x10,
    0x10, 0x10, 0x12, 0x08,
    0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00,
};

static mpu6050_3DData accel_ball_calibrate()
{
    mpu6050_3DData offset = {};
    mpu6050_3DData sample;

    for (int i = 0; i < BALL_CALIB_SAMPLES; i++) {
        mpu6050_getAccelData(&sample);
        offset.x += sample.x;
        offset.y += sample.y;
        offset.z += sample.z;
        HAL_Delay(10);
    }

    offset.x /= BALL_CALIB_SAMPLES;
    offset.y /= BALL_CALIB_SAMPLES;
    offset.z /= BALL_CALIB_SAMPLES;

    return offset;
}

void accel_ball_draw_title(ssd1306_t* screen)
{
    int center_x = SSD1306_WIDTH  / 2;
    int center_y = SSD1306_HEIGHT / 2 + 4;

    ssd1306_fill(screen, BLACK);
    ssd1306_draw_text_aligned(screen, &font_16x16, "BALL GUY", 12, ALIGN_CENTER);

    ssd1306_draw_circle(screen, center_x, center_y + 10, BALL_RADIUS);
    ssd1306_draw_bitmap(screen, SMILEY_BITMAP, center_x - 4, center_y + 8, 8, 8);

    // arms
    ssd1306_draw_line(screen, center_x - BALL_RADIUS, center_y + 10, center_x - BALL_RADIUS - 7, center_y + 12);
    ssd1306_draw_line(screen, center_x + BALL_RADIUS, center_y + 10, center_x + BALL_RADIUS + 7, center_y + 12);

    // legs
    ssd1306_draw_line(screen, center_x - 5, center_y + 10 + BALL_RADIUS, center_x - 8, center_y + 10 + BALL_RADIUS + 8);
    ssd1306_draw_line(screen, center_x + 5, center_y + 10 + BALL_RADIUS, center_x + 8, center_y + 10 + BALL_RADIUS + 8);

    // feet
    ssd1306_draw_line(screen, center_x - 8, center_y + 10 + BALL_RADIUS + 8, center_x - 12, center_y + 10 + BALL_RADIUS + 8);
    ssd1306_draw_line(screen, center_x + 8, center_y + 10 + BALL_RADIUS + 8, center_x + 12, center_y + 10 + BALL_RADIUS + 8);

    ssd1306_update(screen);
}

void accel_ball_shake(ssd1306_t* screen)
{
    uint8_t intensity = 6;

    for (uint8_t i = 0; i < 50; i++) {
        ssd1306_set_line_offset(screen, (i % 2 == 0) ? intensity : 0);
        HAL_Delay(50);

        if (intensity >= 4 && i % 8  ==  7) intensity--;
        if (intensity == 3 && i % 12 == 11) intensity--;
        if (intensity == 2 && i % 16 == 15) intensity--;
        if (intensity == 1 && i % 20 == 19) intensity--;
    }

    ssd1306_set_line_offset(screen, 0);
    HAL_Delay(500);
}

void accel_ball_update_physics(ball_data_t* ball, const mpu6050_3DData* accel, const mpu6050_3DData* calibration)
{
    // swizzle x and y due to accel rotation
    double ax = accel->y - calibration->y;
    double ay = accel->x - calibration->x;

    // remove jittering
    if (abs(ax) < 0.01f)
        ax = 0;
    if (abs(ay) < 0.01f)
        ay = 0;

    ball->vx += ax * BALL_ACCEL_SENSITIVITY * BALL_DT;
    ball->vy += ay * BALL_ACCEL_SENSITIVITY * BALL_DT;

    ball->vx *= BALL_DAMPING;
    ball->vy *= BALL_DAMPING;

    ball->x += ball->vx;
    ball->y += ball->vy;

    const int lo = BALL_BOUNDARY_MARGIN + BALL_RADIUS;
    const int hi_x = SSD1306_WIDTH - BALL_RADIUS - 1;
    const int hi_y = SSD1306_HEIGHT - BALL_RADIUS - 1;

    if (ball->x < lo)
    {
        ball->x = lo;
        ball->vx = -ball->vx * BALL_ENERGY_LOSS;
    }
    if (ball->x > hi_x)
    {
        ball->x = hi_x;
        ball->vx = -ball->vx * BALL_ENERGY_LOSS;
    }
    if (ball->y < lo)
    {
        ball->y = lo;
        ball->vy = -ball->vy * BALL_ENERGY_LOSS;
    }
    if (ball->y > hi_y)
    {
        ball->y = hi_y;
        ball->vy = -ball->vy * BALL_ENERGY_LOSS;
    }
}

void accel_ball_draw_frame(ssd1306_t* screen, const ball_data_t* ball)
{
    ssd1306_fill(screen, BLACK);

    int16_t ix = (int16_t)ball->x;
    int16_t iy = (int16_t)ball->y;

    /* body */
    ssd1306_draw_circle(screen, ix, iy, BALL_RADIUS);

    /* face offset slightly in direction of travel */
    double sx = (fabs(ball->vx) > 0.05) ? (ball->vx > 0 ? 1.0 : -1.0) : 0.0;
    double sy = (fabs(ball->vy) > 0.05) ? (ball->vy > 0 ? 1.0 : -1.0) : 0.0;
    ssd1306_draw_bitmap(screen, SMILEY_BITMAP, ix - 4 + (int)sx, iy - 2 + (int)sy, 8, 8);

    /* border */
    ssd1306_draw_rect(screen, 0, 0, SSD1306_WIDTH, SSD1306_HEIGHT);

    ssd1306_update(screen);
}

void accel_ball_demo(ssd1306_t* screen)
{
    mpu6050_3DData calibration_offset = accel_ball_calibrate();

    accel_ball_draw_title(screen);
    accel_ball_shake(screen);

    ball_data_t ball = {
        .x  = SSD1306_WIDTH  / 2.0,
        .y  = SSD1306_HEIGHT / 2.0,
        .vx = 0.0,
        .vy = 0.0,
    };

    mpu6050_3DData accel;

    while (true) {
        mpu6050_getAccelData(&accel);
        accel_ball_update_physics(&ball, &accel, &calibration_offset);
        accel_ball_draw_frame(screen, &ball);
        HAL_Delay(1000 / BALL_FPS);
    }
}
